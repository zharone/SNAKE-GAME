
# Snake Game Using Raspberry Pi Pico

## Materials List

| No. | Materials / Components | Quantity | Description |
|---|---|---:|---|
| 1 | Raspberry Pi Pico | 1 pc | Main microcontroller |
| 2 | Breadboard (830 points) | 1 pc | Circuit assembly |
| 3 | 2.4-inch TFT Screen (ILI9341) | 1 pc | Game display |
| 4 | KY-023 Joystick Module | 1 pc | Controls snake movement |
| 5 | LiPo Flat Battery (2500–3000 mAh) | 1 pc | Power source |
| 6 | TP4056 Charging Module | 1 pc | Battery charging module |
| 7 | Male Header Pins | 2 pcs | Electrical connections |
| 8 | SPST Rocker Switch | 1 pc | Power switch |
| 9 | Male-to-Male Jumper Wires (30 cm) | As needed | Circuit connections |
| 10 | Male-to-Female Jumper Wires (30 cm) | As needed | Circuit connections |
| 11 | Active Buzzer (3–24V DC) | 1 pc | Sound effects |
