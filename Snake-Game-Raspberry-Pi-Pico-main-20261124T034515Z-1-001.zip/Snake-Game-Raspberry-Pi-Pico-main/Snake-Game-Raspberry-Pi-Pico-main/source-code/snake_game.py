from machine import Pin, SPI, ADC
import time
import random

# =================================
# ILI9341 TFT DISPLAY
# =================================

WIDTH = 320
HEIGHT = 240

spi = SPI(
    1,
    baudrate=30000000,
    polarity=0,
    phase=0,
    sck=Pin(14),
    mosi=Pin(15)
)

cs = Pin(17, Pin.OUT, value=1)
dc = Pin(6, Pin.OUT)
rst = Pin(7, Pin.OUT)

BLACK = 0x0000
WHITE = 0xFFFF
GREEN = 0x07E0
RED = 0xF800
YELLOW = 0xFFE0
BLUE = 0x001F

def command(cmd):
    cs.value(0)
    dc.value(0)
    spi.write(bytes([cmd]))
    cs.value(1)

def data(value):
    cs.value(0)
    dc.value(1)
    spi.write(value)
    cs.value(1)

def init_display():
    rst.value(0)
    time.sleep_ms(100)
    rst.value(1)
    time.sleep_ms(120)

    command(0x01)
    time.sleep_ms(150)
    command(0x28)

    command(0xCF)
    data(bytes([0x00, 0x83, 0x30]))
    command(0xED)
    data(bytes([0x64, 0x03, 0x12, 0x81]))
    command(0xE8)
    data(bytes([0x85, 0x01, 0x79]))
    command(0xCB)
    data(bytes([0x39, 0x2C, 0x00, 0x34, 0x02]))
    command(0xF7)
    data(bytes([0x20]))
    command(0xEA)
    data(bytes([0x00, 0x00]))
    command(0xC0)
    data(bytes([0x26]))
    command(0xC1)
    data(bytes([0x11]))
    command(0xC5)
    data(bytes([0x35, 0x3E]))
    command(0xC7)
    data(bytes([0xBE]))
    command(0x36)
    data(bytes([0x28]))
    command(0x3A)
    data(bytes([0x55]))
    command(0xB1)
    data(bytes([0x00, 0x1B]))
    command(0xB6)
    data(bytes([0x0A, 0x82, 0x27, 0x00]))
    command(0xF2)
    data(bytes([0x00]))
    command(0x26)
    data(bytes([0x01]))

    command(0xE0)
    data(bytes([
        0x0F, 0x31, 0x2B, 0x0C,
        0x0E, 0x08, 0x4E, 0xF1,
        0x37, 0x07, 0x10, 0x03,
        0x0E, 0x09, 0x00
    ]))

    command(0xE1)
    data(bytes([
        0x00, 0x0E, 0x14, 0x03,
        0x11, 0x07, 0x31, 0xC1,
        0x48, 0x08, 0x0F, 0x0C,
        0x31, 0x36, 0x0F
    ]))

    command(0x11)
    time.sleep_ms(120)
    command(0x29)
    time.sleep_ms(50)

# =================================
# FONT A-Z AND 0-9
# =================================

FONT = {
"A":[126,17,17,17,126],
"B":[127,73,73,73,54],
"C":[62,65,65,65,34],
"D":[127,65,65,34,28],
"E":[127,73,73,73,65],
"F":[127,9,9,9,1],
"G":[62,65,73,73,122],
"H":[127,8,8,8,127],
"I":[0,65,127,65,0],
"J":[32,64,65,63,1],
"K":[127,8,20,34,65],
"L":[127,64,64,64,64],
"M":[127,2,12,2,127],
"N":[127,2,4,8,127],
"O":[62,65,65,65,62],
"P":[127,9,9,9,6],
"Q":[62,65,81,33,94],
"R":[127,9,25,41,70],
"S":[38,73,73,73,50],
"T":[1,1,127,1,1],
"U":[63,64,64,64,63],
"V":[31,32,64,32,31],
"W":[63,64,56,64,63],
"X":[99,20,8,20,99],
"Y":[7,8,112,8,7],
"Z":[97,81,73,69,67],

"0":[62,81,73,69,62],
"1":[0,66,127,64,0],
"2":[66,97,81,73,70],
"3":[33,65,69,75,49],
"4":[24,20,18,127,16],
"5":[39,69,69,69,57],
"6":[60,74,73,73,48],
"7":[1,113,9,5,3],
"8":[54,73,73,73,54],
"9":[6,73,73,41,30],

":":[0,54,54,0,0],
" ":[0,0,0,0,0],
"-":[8,8,8,8,8],
".":[0,96,96,0,0]
}

# =================================
# DRAWING FUNCTIONS
# =================================

def set_window(x1, y1, x2, y2):
    command(0x2A)
    data(bytes([x1>>8, x1&255, x2>>8, x2&255]))
    command(0x2B)
    data(bytes([y1>>8, y1&255, y2>>8, y2&255]))
    command(0x2C)

def fill_rect(x, y, w, h, color):
    if w <= 0 or h <= 0:
        return

    if x < 0 or y < 0 or x+w > WIDTH or y+h > HEIGHT:
        return

    set_window(x, y, x+w-1, y+h-1)

    pixel = bytes([color>>8, color&255]) * 500

    cs.value(0)
    dc.value(1)

    remaining = w*h

    while remaining > 0:
        count = min(remaining, 500)
        spi.write(pixel[:count*2])
        remaining -= count

    cs.value(1)

def clear_screen(color=BLACK):
    fill_rect(0, 0, WIDTH, HEIGHT, color)

def draw_text(x, y, text, color, scale=2):
    for char in text:
        pattern = FONT.get(char.upper(), FONT[" "])

        for col in range(5):
            for row in range(7):
                if pattern[col] & (1 << row):
                    fill_rect(
                        x + col*scale,
                        y + row*scale,
                        scale,
                        scale,
                        color
                    )

        x += 6*scale

# =================================
# JOYSTICK
# =================================

joy_x = ADC(26)
joy_y = ADC(27)
joy_sw = Pin(16, Pin.IN, Pin.PULL_UP)

# =================================
# ACTIVE BUZZER - GP18
# =================================


# =================================
# ACTIVE BUZZER - GP18
# SOFTER SOUND EFFECTS
# =================================

buzzer = Pin(18, Pin.OUT)
buzzer.value(0)

def beep(duration):
    buzzer.value(1)
    time.sleep_ms(duration)
    buzzer.value(0)
    time.sleep_ms(80)

# START SOUND
def start_sound():
    beep(70)
    time.sleep_ms(100)
    beep(70)

# EAT FOOD
def eat_sound():
    beep(60)

# NO MOVEMENT SOUND
def move_sound():
    pass

# GAME OVER
def gameover_sound():
    beep(100)
    time.sleep_ms(150)
    beep(150)
    time.sleep_ms(150)
    beep(200)

# VICTORY
def victory_sound():
    beep(70)
    time.sleep_ms(100)
    beep(70)
    time.sleep_ms(100)
    beep(150)

# =================================
# SNAKE SETTINGS
# =================================

CELL = 10
TOP = 20

COLS = 32
ROWS = 22

def draw_cell(pos, color):
    x, y = pos

    fill_rect(
        x*CELL,
        TOP+y*CELL,
        CELL-1,
        CELL-1,
        color
    )

def new_food(snake):
    while True:
        food = (
            random.randint(0, COLS-1),
            random.randint(0, ROWS-1)
        )

        if food not in snake:
            return food

def draw_score(score):
    fill_rect(0, 0, WIDTH, TOP, BLACK)
    draw_text(5, 5, "SCORE:", WHITE, 1)
    draw_text(75, 5, str(score), YELLOW, 1)

# =================================
# START SCREEN
# =================================

def wait_start():
    clear_screen(BLACK)

    draw_text(100, 55, "SNAKE", GREEN, 3)
    draw_text(94, 110, "PRESS", WHITE, 2)
    draw_text(88, 140, "BUTTON", WHITE, 2)

    while joy_sw.value() == 1:
        time.sleep_ms(30)

    time.sleep_ms(50)

    while joy_sw.value() == 0:
        time.sleep_ms(20)

    time.sleep_ms(200)

    start_sound()

# =================================
# GAME OVER SCREEN
# =================================

def game_over(score):
    clear_screen(BLACK)

    draw_text(85, 65, "GAME", RED, 3)
    draw_text(85, 105, "OVER", RED, 3)

    draw_text(65, 165, "SCORE:", WHITE, 2)
    draw_text(190, 165, str(score), YELLOW, 2)

    draw_text(45, 210, "PRESS BUTTON", WHITE, 1)

    gameover_sound()

# =================================
# PLAY GAME
# =================================

def play_game():

    snake = [
        (15, 10),
        (14, 10),
        (13, 10)
    ]

    direction = (1, 0)
    food = new_food(snake)

    score = 0
    speed = 0.15

    clear_screen(BLACK)
    draw_score(score)

    for part in snake:
        draw_cell(part, GREEN)

    draw_cell(food, RED)

    while True:

        x = joy_x.read_u16()
        y = joy_y.read_u16()

        # JOYSTICK MOVEMENT

        if x < 12000 and direction != (1, 0):
            direction = (-1, 0)

        elif x > 53000 and direction != (-1, 0):
            direction = (1, 0)

        elif y < 12000 and direction != (0, 1):
            direction = (0, -1)

        elif y > 53000 and direction != (0, -1):
            direction = (0, 1)

        # NEW SNAKE HEAD

        head = (
            snake[0][0] + direction[0],
            snake[0][1] + direction[1]
        )

        eating = head == food

        body = snake if eating else snake[:-1]

        # COLLISION DETECTION

        if (
            head[0] < 0 or head[0] >= COLS or
            head[1] < 0 or head[1] >= ROWS or
            head in body
        ):
            game_over(score)
            return

        # MOVE SNAKE

        snake.insert(0, head)
        draw_cell(head, GREEN)

        # EAT FOOD

        if eating:

            score += 1

            eat_sound()

            draw_score(score)

            if len(snake) == COLS * ROWS:
                clear_screen(BLACK)
                draw_text(80, 90, "YOU WIN", YELLOW, 3)
                victory_sound()
                return

            food = new_food(snake)
            draw_cell(food, RED)

            # INCREASE SPEED

            speed = max(0.045, speed - 0.005)

        else:

            tail = snake.pop()
            draw_cell(tail, BLACK)

            move_sound()

        time.sleep(speed)

# =================================
# MAIN PROGRAM
# =================================

init_display()
clear_screen(BLACK)

while True:
    wait_start()
    play_game()
