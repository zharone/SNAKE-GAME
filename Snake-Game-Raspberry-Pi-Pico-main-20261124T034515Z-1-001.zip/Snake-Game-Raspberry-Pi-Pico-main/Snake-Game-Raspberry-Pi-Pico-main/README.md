# 🐍 Snake Game Using Raspberry Pi Pico

## 📌 Project Overview
The Snake Game is a simple arcade-style game developed using a Raspberry Pi Pico, a 2.4-inch ILI9341 TFT display, and a KY-023 joystick.

The player controls the snake using the joystick to collect food, increase the score, and avoid hitting the walls or the snake's body.

## 🎯 Project Objectives
- Develop a playable Snake Game using Raspberry Pi Pico.
- Learn and apply MicroPython programming.
- Understand hardware connections and electronic components.
- Practice embedded systems development.

## 🛠️ Hardware Components
- Raspberry Pi Pico
- 2.4-inch ILI9341 TFT Display
- KY-023 Joystick
- Breadboard
- Jumper Wires

## 💻 Software and Tools
- MicroPython
- Thonny IDE
- GitHub

## 📂 Repository Contents
| Folder/File | Description |
|---|---|
| `source-code/` | Python source code |
| `game-screenshots/` | Actual screenshots of the game |
| `game-videos/` | Game demonstration video |
| `schematic/` | Circuit diagram and wiring connections |
| `materials/` | Materials list |

## 🔌 Circuit Connections
The Raspberry Pi Pico is connected to the ILI9341 TFT display and KY-023 joystick.

See the `schematic/` folder for the circuit diagram and complete wiring connections.

## 🎮 Game Features
- Joystick-controlled snake movement
- Food collection
- Score tracking
- Game-over condition

## 📸 Game Screenshots
Actual photos and screenshots of the working prototype will be uploaded in the `game-screenshots/` folder.

## 🎥 Game Demonstration
The demonstration video will be uploaded in the `game-videos/` folder.

## 👨‍💻 Developer
**Ken Akimoto**

## 🚀 Project Platform
**Hardware:** Raspberry Pi Pico  
**Programming Language:** MicroPython

---
*Computer Engineering Project*
